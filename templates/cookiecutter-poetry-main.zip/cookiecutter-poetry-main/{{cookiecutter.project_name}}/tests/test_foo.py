from {{cookiecutter.project_slug}}.foo import foo


def test_foo():
    assert foo("foo") == "foo"
