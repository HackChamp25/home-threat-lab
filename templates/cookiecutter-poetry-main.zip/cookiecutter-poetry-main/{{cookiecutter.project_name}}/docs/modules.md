::: {{cookiecutter.project_slug}}.foo
